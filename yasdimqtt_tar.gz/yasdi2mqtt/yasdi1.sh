#!/bin/bash

cd /home/iplon/repos/yasdi2mqtt/


docker-compose -f docker-compose.yml up -d
